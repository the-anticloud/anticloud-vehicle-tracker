# 25 Millennium Problem Proposals

**Project:** VEHICLE_TRACKER
**Upstream:** https://github.com/nicedoc/vehicle-tracker

Content specific to VEHICLE_TRACKER in category AUTOMOTIVE.
