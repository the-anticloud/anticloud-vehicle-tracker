# OSINT Benchmark — VEHICLE_TRACKER

**Upstream:** https://github.com/nicedoc/vehicle-tracker

Public-record information collected about upstream project:

- GitHub stars: see upstream
- License: MIT
- Last commit: check upstream
- Known CVEs: check NVD

Status: PENDING systematic collection.
