# Compliance — VEHICLE_TRACKER

**Upstream:** https://github.com/nicedoc/vehicle-tracker
**License:** MIT

## License Compliance

- Upstream MIT license preserved in all distributions
- No GPL/AGPL contamination in dependency tree
- Anticloud additions under Anticommons 0.1.0
- All dependencies pinned to audited versions

## Data Compliance

- AES-256 encryption at rest for all sensitive data
- AIOSS append-only audit trail (GDPR Article 30 aligned)
- Zero third-party data transmission in offline mode
- Role-based access control with cryptographic audit log

## Security Compliance

- OWASP Top 10 mitigations applied (see OFFICIAL_BENCHMARKS/03_OWASP.md)
- Dependency vulnerability scanning via local OSV database
- No telemetry or analytics transmitted externally

## Status

Compliance review pending first verified build.
